<h1 class="text-center "><strong>BIENVENIDOS</strong></h1>
<h2 class="text-center text-secondary ">Seguí leyendo para conocer un poco mas sobre nuestra agencia :)</h2>

<div class="card my-5 " style="max-width: 900px;">
  <div class="row g-0 ">
    <div class="col-md-4">
      <img src="recursos/img/logo_completo.png" class="img-fluid rounded-start" alt="logo">
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h2 class="card-title text-center">¿QUIENES SOMOS?</h2>
        <p class="card-text"> <strong style="font-size: larger;">Somos un estudio de diseño con sede en Buenos Aires, Argentina.</strong> <br>
        Creamos la imagen visual y brindamos soluciones gráficas para grandes empresas y agencias de publicidad. Ayudándolos a comunicar y promover sus productos y servicios. <br>
        ¿Queres conocernos más? Apretá el botón y descubrí sobre nuestros increíbles empleados.</p>
        <a  class="btn btn-primary dale" data-bs-toggle="collapse" href="#empleados" role="button" aria-expanded="false" aria-controls="empleados" >¡DALE!</a>
      </div>
    </div>
  </div>
</div>

<?php
$consultaEmpleados = "SELECT 
        empleados.NOMBRE, 
        empleados.APELLIDO, 
        empleados.FOTO
    FROM
        id22111537_abstract_less.empleados"
       ;
$res = mysqli_query($conexion, $consultaEmpleados);
$empleados = [];
while ($fila = mysqli_fetch_assoc($res)) {
    $empleados[] = $fila;
};   ?>

<div class="collapse " id="empleados" >
  <div class="card" >
    <h3 class="text-info text-center" style="text-decoration: underline solid 2px ">EMPLEADOS</h3>
    <div class="container">
      <div class="row justify-content-center">
         <?php
          foreach ($empleados as $empleado): 
            echo '<div class="col-lg-4 col-md-6 col-sm-12">';
            echo '<img class="img-fluid " src="recursos/img/empleados/' . $empleado['FOTO'] . '" alt="empleado">';
            echo '<h5 class="card-title my-2 text-center" style="text-transform:uppercase;" >' . $empleado['NOMBRE'] . ' ' . $empleado['APELLIDO'] . '</h5>';
            echo '</div>';
          endforeach;
        ?>
      </div>
    </div>
  </div>
</div>


<?php
$consultaServicios = "SELECT 
        servicios.SERVICIO, 
        servicios.DESCRIPCION,
        servicios.ICON
    FROM
    id22111537_abstract_less.servicios"
       ;
$res = mysqli_query($conexion, $consultaServicios);
$servicios = [];
while ($fila = mysqli_fetch_assoc($res)) {
    $servicios[] = $fila;
};  ?>

<div class="container mt-3">
    <h2 class="text-center mb-4">¿QUÉ SERVICIOS OFRECEMOS?</h2>
    <div class="row row-cols-1 row-cols-md-3 g-4 justify-content-center">
        <?php
          foreach ($servicios as $servicio): 
            echo '<div class="col">';
            echo '<div class="card h-100">';
            echo '<div class="col d-flex justify-content-center">';
            echo '<img class="img-fluid rounded-start mt-4" src="recursos/img/servicios/' . $servicio['ICON'] . '" alt="servicio" > </div>';
            echo '<div class="card-body">';
            echo '<h4 class="card-title text-center" style="text-transform:uppercase;">' . $servicio['SERVICIO'] . '</h4>';
            echo '<p class="card-text text-center">' . $servicio['DESCRIPCION'] . '</p>';
            echo '</div> </div> </div>';
          endforeach;
        ?>
    </div>
</div>